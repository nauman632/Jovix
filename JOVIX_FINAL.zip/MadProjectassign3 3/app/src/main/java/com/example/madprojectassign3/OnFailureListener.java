package com.example.madprojectassign3;

import androidx.annotation.NonNull;

public class OnFailureListener implements com.google.android.gms.tasks.OnFailureListener {
    @Override
    public void onFailure(@NonNull Exception e) {

    }
}
