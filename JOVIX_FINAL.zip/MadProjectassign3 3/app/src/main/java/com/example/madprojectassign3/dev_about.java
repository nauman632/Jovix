package com.example.madprojectassign3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class dev_about extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dev_about);
    }
}