package com.example.madprojectassign3;

public interface OnSuccessListener {
}
